
import { GoogleGenAI } from "@google/genai";
import { PatientProfile, AnamnesisData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const getGeminiSummaryForClinic = async (profile: PatientProfile, anamnesis: AnamnesisData) => {
  const model = "gemini-3-flash-preview";
  
  const behaviorContext = profile.behavioralData ? `
    DADOS DE COMPORTAMENTO DIGITAL (Últimas 24h):
    - Escrita em outros apps: ${profile.behavioralData.externalKeystrokesSummary}
    - Apps mais usados/Humor: ${profile.behavioralData.appUsageBehavior}
  ` : "Dados comportamentais não disponíveis.";

  const prompt = `
    Analise os dados deste paciente VIP e gere um relatório estratégico para o CRM da clínica.
    O objetivo é preparar o profissional para a consulta de amanhã.

    PACIENTE:
    - Nome: ${profile.name}
    - Objetivo: ${profile.objective}
    - Estilo desejado: ${profile.style}

    ANAMNESE:
    - Saúde/Alergias: ${anamnesis.healthGeneral}, ${anamnesis.allergies}
    - Resultado Esperado: ${anamnesis.expectedResult}

    ${behaviorContext}

    Gere um relatório estruturado:
    1. PERFIL COMPLETO: Quem é o paciente (hobbies, trabalho, humor atual).
    2. ANÁLISE DE EXPECTATIVA: O humor digital condiz com o resultado esperado?
    3. ALERTA PSICOLÓGICO/SAÚDE: Há sinais de ansiedade ou doenças mencionadas externamente?
    4. CRONOGRAMA DE ABORDAGEM: Como o recepcionista e o médico devem falar com ele amanhã.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Erro ao gerar resumo da IA.";
  }
};

export const chatWithGemini = async (message: string, history: { role: string, parts: string }[]) => {
  const model = "gemini-3-flash-preview";
  try {
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction: "Você é o assistente virtual da Clínica VIP Estética. Seja extremamente educado, refinado e utilize termos que transmitam segurança e exclusividade. Ajude o paciente com dúvidas sobre pré e pós operatório baseado em protocolos de estética de luxo.",
      }
    });
    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    return "Desculpe, estou tendo dificuldades técnicas.";
  }
};
