
import React, { useState, useEffect } from 'react';
import { PatientProfile, RewardPoints, AppStep, Reminder } from '../types';

interface Props {
  profile: PatientProfile;
  rewards: RewardPoints;
  onOpenChat: () => void;
  onNavigate: (step: AppStep) => void;
  onMoodCheckin: (mood: string) => void;
}

const DashboardView: React.FC<Props> = ({ profile, rewards, onOpenChat, onNavigate, onMoodCheckin }) => {
  const [activeReminder, setActiveReminder] = useState<Reminder | null>(null);
  const firstName = profile?.name?.split(' ')[0] || 'Paciente';

  useEffect(() => {
    const allRecords = JSON.parse(localStorage.getItem('clinic_records') || '[]');
    const myRecord = allRecords.find((r: any) => r.profile.id === profile.id);
    if (myRecord?.reminders?.length > 0) {
      const unread = myRecord.reminders.find((rem: Reminder) => !rem.read);
      if (unread) setActiveReminder(unread);
    }
  }, [profile.id]);

  const closeReminder = () => {
    setActiveReminder(null);
    // Marcar como lido no storage real seria feito aqui
  };

  return (
    <div className="flex flex-col space-y-6 pb-20 relative">
      {/* Pop-up de Lembrete Elegante */}
      {activeReminder && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-6 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#1A1A1B] border border-sage/30 rounded-3xl p-8 w-full shadow-2xl shadow-sage/5 transform animate-in fade-in zoom-in duration-300">
            <div className="w-12 h-12 bg-sage/10 rounded-full flex items-center justify-center mb-6 mx-auto">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-sage" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v1m6 0H9" />
               </svg>
            </div>
            <h3 className="text-xl font-serif text-center mb-2">{activeReminder.title}</h3>
            <p className="text-sm text-white/60 text-center leading-relaxed mb-8">
              {activeReminder.message}
            </p>
            <button 
              onClick={closeReminder}
              className="w-full py-4 bg-sage text-[#1A1A1B] font-bold rounded-2xl"
            >
              Entendido
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-sm font-light text-white/60">Olá, {firstName}</h2>
          <p className="text-lg font-serif">Sua Jornada VIP</p>
        </div>
        <div className="bg-sage/10 border border-sage/20 rounded-full px-4 py-2 flex items-center space-x-2">
          <span className="text-xs font-semibold text-sage">{rewards.total} pts</span>
          <div className="w-2 h-2 rounded-full bg-sage animate-pulse" />
        </div>
      </div>

      {/* Check-in de Humor (Emotional Tracking Plugin) */}
      <div className="bg-white/5 border border-white/10 rounded-3xl p-5">
        <h3 className="text-[10px] uppercase tracking-widest text-white/40 mb-3 text-center">Como você está se sentindo hoje?</h3>
        <div className="flex justify-around">
          {['😔', '😐', '😊', '✨'].map((emoji, idx) => (
            <button 
              key={idx}
              onClick={() => onMoodCheckin(emoji)}
              className="text-2xl hover:scale-125 transition-transform p-2 grayscale hover:grayscale-0"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>

      {/* Rastreamento Inteligente Status */}
      <div className="flex items-center space-x-3 px-4 py-2 bg-sage/5 rounded-full border border-sage/10">
        <div className="flex space-x-1">
          <div className="w-1.5 h-1.5 bg-sage rounded-full animate-ping" />
        </div>
        <span className="text-[9px] uppercase tracking-[0.2em] text-sage font-bold">Monitoramento de Comportamento Ativo</span>
      </div>

      {/* Bloco de Próximo Atendimento */}
      <div className="bg-white/5 border-l-4 border-sage rounded-xl p-5 flex justify-between items-center group hover:bg-white/10 transition-all cursor-pointer">
        <div>
          <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Seu próximo atendimento</span>
          <h3 className="text-lg font-serif sage-green mt-1">Sexta-feira, 25 de Outubro</h3>
          <p className="text-[10px] text-white/60 mt-0.5">Horário: 14:30h • Dra. Sofia</p>
        </div>
      </div>

      {/* Grid Features */}
      <div className="grid grid-cols-2 gap-4">
        <button onClick={() => onNavigate(AppStep.REWARDS)} className="bg-white/5 border border-white/10 rounded-2xl p-5 text-left flex flex-col justify-between h-32 hover:bg-white/10 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sage-green" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
          <div><span className="text-sm font-semibold block">Indicar</span><span className="text-[10px] text-white/40">Ganhe prêmios</span></div>
        </button>
        <button onClick={() => onNavigate(AppStep.EVOLUTION)} className="bg-white/5 border border-white/10 rounded-2xl p-5 text-left flex flex-col justify-between h-32 hover:bg-white/10 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 sage-green" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /></svg>
          <div><span className="text-sm font-semibold block">Diário</span><span className="text-[10px] text-white/40">Acompanhe fotos</span></div>
        </button>
      </div>
    </div>
  );
};

export default DashboardView;
