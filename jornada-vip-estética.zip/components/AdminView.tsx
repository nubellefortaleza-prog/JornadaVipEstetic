
import React, { useState, useEffect } from 'react';
import { PatientRecord, Reminder } from '../types';
import { getGeminiSummaryForClinic } from '../services/geminiService';

interface Props {
  onBack: () => void;
}

const AdminView: React.FC<Props> = ({ onBack }) => {
  const [records, setRecords] = useState<PatientRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<PatientRecord | null>(null);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [remTitle, setRemTitle] = useState('');
  const [remMsg, setRemMsg] = useState('');

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('clinic_records') || '[]');
    setRecords(data);
  }, []);

  const handleViewPatient = async (record: PatientRecord) => {
    setSelectedRecord(record);
    setAiSummary(null);
    setLoadingAi(true);
    const summary = await getGeminiSummaryForClinic(record.profile, record.anamnesis);
    setAiSummary(summary || "Sem resumo disponível.");
    setLoadingAi(false);
  };

  const handleSendReminder = () => {
    if (!selectedRecord || !remTitle || !remMsg) return;
    
    const newReminder: Reminder = {
      id: Math.random().toString(36).substr(2, 9),
      patientId: selectedRecord.profile.id,
      title: remTitle,
      message: remMsg,
      date: new Date().toISOString(),
      type: 'orientacao',
      read: false
    };

    const updatedRecords = records.map(r => {
      if (r.profile.id === selectedRecord.profile.id) {
        return { ...r, reminders: [...(r.reminders || []), newReminder] };
      }
      return r;
    });

    localStorage.setItem('clinic_records', JSON.stringify(updatedRecords));
    setRecords(updatedRecords);
    setSelectedRecord({ ...selectedRecord, reminders: [...(selectedRecord.reminders || []), newReminder] });
    setRemTitle('');
    setRemMsg('');
    alert('Lembrete enviado ao app do paciente!');
  };

  return (
    <div className="flex flex-col flex-1 pb-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-serif">Painel Clínico</h2>
          <p className="text-xs text-white/40">Inteligência de Pacientes</p>
        </div>
        <button onClick={onBack} className="text-xs sage-green uppercase tracking-widest font-bold">Sair</button>
      </div>

      {!selectedRecord ? (
        <div className="space-y-4">
          <h3 className="text-xs uppercase tracking-widest text-white/40 ml-1">Fichas Prontas para Consulta</h3>
          {records.length === 0 ? (
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 text-center">
              <p className="text-sm text-white/40">Aguardando novos cadastros...</p>
            </div>
          ) : (
            records.map((r, i) => (
              <button 
                key={i}
                onClick={() => handleViewPatient(r)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between hover:border-sage/50 transition-all"
              >
                <div className="text-left">
                  <p className="font-medium">{r.profile.name}</p>
                  <p className="text-[10px] text-white/40 uppercase tracking-tighter">{r.profile.objective}</p>
                </div>
                <div className="text-right">
                   <span className="text-[10px] sage-green font-bold">Abrir IA</span>
                </div>
              </button>
            ))
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <button onClick={() => setSelectedRecord(null)} className="flex items-center space-x-2 text-xs text-white/40">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Voltar</span>
          </button>

          {/* Enviar Lembrete */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-6">
            <h4 className="text-xs font-bold uppercase tracking-widest text-sage mb-4">Programar Lembrete / Popup</h4>
            <div className="space-y-3">
              <input 
                className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2 text-xs outline-none focus:border-sage"
                placeholder="Título (Ex: Lembrete de Consulta)"
                value={remTitle}
                onChange={(e) => setRemTitle(e.target.value)}
              />
              <textarea 
                className="w-full bg-black/20 border border-white/10 rounded-xl px-4 py-2 text-xs outline-none focus:border-sage min-h-[60px]"
                placeholder="Mensagem da orientação..."
                value={remMsg}
                onChange={(e) => setRemMsg(e.target.value)}
              />
              <button 
                onClick={handleSendReminder}
                className="w-full py-2 bg-sage text-[#1A1A1B] text-xs font-bold rounded-xl"
              >
                Enviar ao Paciente
              </button>
            </div>
          </div>

          <div className="bg-sage/5 border border-sage/20 rounded-3xl p-6">
            <h4 className="text-xs font-bold uppercase tracking-widest sage-green mb-4">Relatório de IA e Cronograma</h4>
            {loadingAi ? (
              <div className="py-4 text-xs text-white/40">Processando dados comportamentais...</div>
            ) : (
              <p className="text-xs leading-relaxed text-white/80 whitespace-pre-line">{aiSummary}</p>
            )}
          </div>

          <div className="bg-white/5 border border-white/10 rounded-3xl p-6">
            <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-4">Monitoramento Comportamental (Logs)</h4>
            <div className="space-y-4">
               <div className="p-3 bg-black/20 rounded-xl">
                <p className="text-[9px] uppercase text-white/20 mb-1">Humor Relatado (Emotional Tracking)</p>
                <p className="text-xl">{selectedRecord.profile.behavioralData?.moodCheckin || "Nenhum check-in"}</p>
              </div>
              <div className="p-3 bg-black/20 rounded-xl">
                <p className="text-[9px] uppercase text-white/20 mb-1">Interesses para Marketing</p>
                <p className="text-[11px] text-white/70 italic">
                  {selectedRecord.profile.behavioralData?.externalKeystrokesSummary || "Buscando tendências..."}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
