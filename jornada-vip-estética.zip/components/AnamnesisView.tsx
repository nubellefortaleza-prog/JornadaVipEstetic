
import React, { useState } from 'react';
import { AnamnesisData } from '../types';

interface Props {
  onComplete: (data: AnamnesisData) => void;
}

const AnamnesisView: React.FC<Props> = ({ onComplete }) => {
  const [currentBlock, setCurrentBlock] = useState(0);
  const [data, setData] = useState<Partial<AnamnesisData>>({
    pregnancy: false,
    habits: { sun: 'baixa', sleep: '7-8h', smoking: false, skincare: 'básico' }
  });

  const blocks = [
    { title: "Saúde Geral", fields: ["healthGeneral", "allergies", "medications"] },
    { title: "Hábitos e Estilo de Vida", fields: ["habits"] },
    { title: "Histórico e Expectativas", fields: ["pastProcedures", "expectedResult"] }
  ];

  const handleNext = () => {
    if (currentBlock < blocks.length - 1) {
      setCurrentBlock(currentBlock + 1);
    } else {
      onComplete(data as AnamnesisData);
    }
  };

  return (
    <div className="flex flex-col flex-1">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-serif text-white/90">Anamnese</h2>
        <span className="text-xs text-white/40">Bloco {currentBlock + 1} de {blocks.length}</span>
      </div>

      <div className="space-y-6">
        {currentBlock === 0 && (
          <>
            <div>
              <label className="text-xs text-white/60 block mb-2">Possui doenças crônicas ou condições de saúde?</label>
              <textarea 
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 min-h-[100px] outline-none"
                placeholder="Ex: Diabetes, Hipertensão..."
                onChange={(e) => setData({...data, healthGeneral: e.target.value})}
              />
            </div>
            <div>
              <label className="text-xs text-white/60 block mb-2">Possui alergias alimentares ou medicamentosas?</label>
              <input 
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none"
                placeholder="Ex: Iodo, Dipirona, Latex..."
                onChange={(e) => setData({...data, allergies: e.target.value})}
              />
            </div>
          </>
        )}

        {currentBlock === 1 && (
          <>
            <div>
              <label className="text-xs text-white/60 block mb-2">Exposição solar diária</label>
              <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none">
                <option>Baixa (Ambiente interno)</option>
                <option>Moderada (Uso casual)</option>
                <option>Alta (Atividades externas)</option>
              </select>
            </div>
            <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
              <span className="text-sm">Tabagismo</span>
              <button 
                onClick={() => setData({...data, habits: {...data.habits!, smoking: !data.habits?.smoking}})}
                className={`w-12 h-6 rounded-full relative transition-colors ${data.habits?.smoking ? 'bg-sage' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${data.habits?.smoking ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
          </>
        )}

        {currentBlock === 2 && (
          <>
            <div>
              <label className="text-xs text-white/60 block mb-2">Procedimentos que já realizou</label>
              <textarea 
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 min-h-[80px] outline-none"
                placeholder="Ex: Botox há 6 meses, preenchimento labial..."
                onChange={(e) => setData({...data, pastProcedures: e.target.value})}
              />
            </div>
            <div>
              <label className="text-xs text-white/60 block mb-2">Qual o resultado esperado ao final do tratamento?</label>
              <textarea 
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 min-h-[100px] outline-none"
                placeholder="Descreva seu sonho..."
                onChange={(e) => setData({...data, expectedResult: e.target.value})}
              />
            </div>
          </>
        )}
      </div>

      <button 
        onClick={handleNext}
        className="mt-auto mb-6 w-full py-4 bg-sage text-[#1A1A1B] font-semibold rounded-2xl shadow-lg shadow-sage/10 transition-all active:scale-95"
      >
        {currentBlock === blocks.length - 1 ? "Confirmar e Finalizar" : "Próximo Bloco"}
      </button>
    </div>
  );
};

export default AnamnesisView;
