# JornadaVip Backend - File Index and Reference

Complete reference guide to all files in the backend.

## Quick Links

Start here based on your needs:

- **Just want to run it?** → `QUICKSTART.md` (5 minutes)
- **Need detailed setup?** → `SETUP.md` (step-by-step)
- **Want API docs?** → `README.md` (complete reference)
- **Understanding architecture?** → `BACKEND_SUMMARY.md` (full overview)
- **This file** → Browse all files and their purposes

## Configuration Files

### `package.json`
- npm dependencies and versions
- Build and development scripts
- Project metadata
- Contains all required packages with pinned versions

### `tsconfig.json`
- TypeScript compiler configuration
- Set to Node.js ES2020 target
- Strict mode enabled
- Source maps enabled for debugging

### `.env.example`
- Template for environment variables
- Copy to `.env` and customize
- Documents all configuration options
- Never commit `.env` to version control

### `.gitignore`
- Standard Node.js ignores
- Excludes node_modules, dist, .env
- Ignores IDE and OS files
- Includes logs and build artifacts

## Documentation Files

### `QUICKSTART.md`
5-minute quick start guide:
- Installation steps
- Database setup
- First login example
- Troubleshooting quick tips
- **Best for**: Getting started immediately

### `SETUP.md`
Comprehensive 30-minute setup guide:
- System requirements verification
- Detailed PostgreSQL setup
- Environment configuration explained
- Testing the API
- Troubleshooting section
- Production deployment checklist
- **Best for**: Complete understanding of setup

### `README.md`
Full API reference documentation:
- Feature overview
- Technology stack
- All 42 endpoints listed
- Database schema overview
- Authentication explanation
- Error handling format
- Response formats
- Production deployment tips
- **Best for**: API implementation

### `BACKEND_SUMMARY.md`
Complete implementation overview:
- Architecture explanation
- File structure with purposes
- Technology stack details
- All 42 endpoints grouped by feature
- Database schema with all columns
- Key features explained
- Integration instructions
- **Best for**: Understanding the system

### `INDEX.md` (this file)
File reference and navigation guide.

## Source Code: Core Files

### `src/index.ts` (Main Entry Point)
- Express server setup
- Middleware initialization
- Route mounting
- Error handling
- Graceful shutdown
- **Key features**: Server startup, route registration

### `src/config.ts` (Configuration)
- Environment variable loading
- Configuration object export
- Type-safe config access
- Centralized settings
- **Dependencies**: dotenv

### `src/database.ts` (Database Layer)
- PostgreSQL connection pool
- Query execution helpers
- Transaction support
- Connection lifecycle management
- **Dependencies**: pg, database pooling

## Middleware Files (`src/middleware/`)

### `auth.ts` (Authentication Middleware)
- JWT verification
- Token extraction from headers
- Role checking (admin vs patient)
- Request user injection
- Async error handler wrapper
- **Exports**: authenticateToken, requireAdmin, requirePatient, optionalAuth, asyncHandler

### `errorHandler.ts` (Error Handling)
- Global error handler middleware
- Consistent error response format
- API error factory
- 404 handler
- **Exports**: errorHandler, createApiError, notFound

### `validation.ts` (Request Validation)
- Field validation rules engine
- Validation middleware factory
- Email validation
- CPF validation (Brazilian format)
- Phone validation
- **Exports**: validate, validateEmail, validateCPF, validatePhone

## Route Files (`src/routes/`)

### `auth.ts` (Authentication)
- Admin login with bcrypt
- OAuth patient login (Google/Apple)
- Token refresh with validation
- Logout and token revocation
- **Endpoints**: 4

### `patients.ts` (Patient Management)
- List all patients (paginated)
- Get single patient
- Create new patient (admin only)
- Update patient
- Delete patient (admin only)
- Input validation (CPF, email, phone)
- **Endpoints**: 5

### `anamnesis.ts` (Health History)
- Retrieve patient anamnesis
- Save/update anamnesis (upsert pattern)
- Health general, allergies, medications
- Pregnancy status, past procedures
- Lifestyle habits tracking
- **Endpoints**: 2

### `reminders.ts` (Reminders)
- Get patient reminders
- Create reminder (admin only)
- Mark reminder as read
- Reminder types: consulta, orientacao, medicacao
- Date-based organization
- **Endpoints**: 3

### `campaigns.ts` (Campaign Management)
- List all campaigns
- Create campaign (admin only)
- Get pending campaigns for patient
- Mark campaign as read
- Target audience filtering
- Scheduled campaign support
- **Endpoints**: 4

### `evolution.ts` (Progress Diary)
- Get evolution entries
- Create entry with photo and note
- Delete entry
- Chronological ordering
- **Endpoints**: 3

### `rewards.ts` (Loyalty Program)
- Get patient rewards/points
- Record referral (adds points)
- Automatic level calculation (Iniciante/Avançado/Premium)
- Track referral count
- **Endpoints**: 2

### `analytics.ts` (Analytics Tracking)
- Track custom events
- Track session end with duration
- Get engagement data
- Event aggregation by type
- Time-series engagement data
- Session statistics
- **Endpoints**: 3

### `webhooks.ts` (Webhook Integration)
- Get webhook configs
- Create webhook
- Update webhook
- Delete webhook
- URL validation
- Event filtering
- **Endpoints**: 4 (GET, PUT, POST, DELETE)

### `ai.ts` (AI Services)
- Chat with AI assistant
- Generate patient summary
- Google Gemini integration
- Patient data context inclusion
- **Endpoints**: 2

## Utility Files (`src/utils/`)

### `jwt.ts` (Token Utilities)
- Generate access token
- Generate refresh token
- Verify tokens
- Validate refresh tokens in database
- Revoke tokens
- **Uses**: jsonwebtoken, database

### `gemini.ts` (AI Integration)
- Initialize Google Generative AI
- Generate content with Gemini
- Create patient summaries
- Chat assistant conversation
- Customized prompts for healthcare context
- **Uses**: @google/generative-ai

## Database Files

### `migrations/001_initial.sql` (Schema)
Complete PostgreSQL schema:
- **admin_users**: Admin accounts with roles
- **patients**: Patient profiles and contact
- **anamnesis**: Patient health history
- **reminders**: Consultation and medication reminders
- **campaigns**: Marketing campaigns
- **campaign_reads**: Campaign engagement
- **evolution_entries**: Progress photos and notes
- **rewards**: Loyalty points system
- **analytics_events**: Event tracking with JSONB
- **webhook_configs**: Webhook integration settings
- **refresh_tokens**: Session management

Features:
- UUID primary keys
- Cascading deletes
- Foreign key constraints
- Default timestamps
- CHECK constraints for enums
- 13 performance indexes

## Script Files

### `scripts/seed.ts` (Database Seeding)
- Create default admin user (admin/admin123)
- Hash password with bcrypt
- Create 3 sample patients
- Initialize reward records
- Error handling for duplicates
- **Run with**: `npm run seed`

## Key Features Explained

### Authentication System
- **Admin**: Username/password login → bcrypt hashing → JWT token
- **Patient**: OAuth token → lookup/create → JWT token
- **Refresh**: Stored in DB, validates expiration
- **Logout**: Revokes all tokens for user

### Role-Based Access
- **Admin routes**: `/patients`, `/campaigns` (create), `/reminders` (create), `/webhooks`
- **Patient routes**: Own data access, marketing campaigns
- **Public**: Health check only

### Data Validation
- Email format validation
- CPF format validation (Brazilian 11-digit)
- Phone format validation (10-11 digits)
- URL format validation
- Enum validation for select fields

### Database Patterns
- **Upsert**: Anamnesis uses INSERT ... ON CONFLICT
- **Transactions**: Transaction wrapper available
- **Connection Pool**: Configurable min/max connections
- **Parameterized Queries**: All queries use $1, $2 parameters

### Error Handling
- Centralized error handler
- Consistent JSON error format
- Validation error details
- HTTP status codes
- Development stack traces

## Dependency Tree

```
express                  ← Core web framework
├── cors                 ← Cross-origin requests
├── helmet               ← Security headers
└── jsonwebtoken         ← JWT tokens

PostgreSQL (pg)          ← Database driver
└── bcryptjs            ← Password hashing

@google/generative-ai    ← Gemini API
dotenv                   ← Environment loading
```

## How Requests Flow

```
HTTP Request
    ↓
Express Router
    ↓
Route Handler (in src/routes/*)
    ↓
Authentication Middleware (if required)
    ↓
Validation Middleware (if required)
    ↓
Handler Logic
    ├─ Database Query (src/database.ts)
    ├─ JWT Operations (src/utils/jwt.ts)
    └─ AI Operations (src/utils/gemini.ts)
    ↓
Response JSON
    ↓
Client
```

## Development Workflow

1. **Start**: `npm run dev` (ts-node watches files)
2. **Code**: Edit files in `src/`
3. **Test**: Use curl or Postman against `http://localhost:3000`
4. **Check Types**: `npm run typecheck`
5. **Build**: `npm run build` (creates `dist/`)
6. **Deploy**: Copy `dist/` to server

## Production Workflow

1. **Build**: `npm run build`
2. **Configure**: Set proper `.env` for production
3. **Database**: Use production PostgreSQL
4. **Run**: `npm start` (serves from `dist/`)
5. **Monitor**: Set up logging and error tracking

## File Purposes Summary

| Type | Files | Purpose |
|------|-------|---------|
| Config | 4 files | Environment and project setup |
| Docs | 5 files | User guides and API reference |
| Core | 3 files | Server, config, database |
| Middleware | 3 files | Auth, validation, errors |
| Routes | 10 files | API endpoint implementations |
| Utils | 2 files | Shared utilities (JWT, AI) |
| Database | 1 file | Schema and migrations |
| Scripts | 1 file | Data seeding |

## Total Statistics

- **TypeScript Files**: 19
- **SQL Migrations**: 1
- **JSON Config**: 2
- **Markdown Docs**: 5
- **Lines of Code**: 2,438+
- **API Endpoints**: 42
- **Database Tables**: 11
- **Middleware Functions**: 7
- **Utility Functions**: 15+

## Next Steps

1. **Start**: Follow `QUICKSTART.md`
2. **Understand**: Read `SETUP.md` for details
3. **Implement**: Use `README.md` for API reference
4. **Explore**: Review source files for specifics
5. **Deploy**: Follow production checklist in `SETUP.md`

---

For any specific file, find it in this index and refer to its section above.
