# JornadaVip Backend - Quick Start Guide

Get the backend running in 5 minutes.

## Prerequisites

- Node.js 20+
- PostgreSQL 12+
- npm

## Installation (5 steps)

### 1. Install Dependencies
```bash
npm install
```

### 2. Create Database
```bash
createdb jornadavip
psql -U postgres -d jornadavip -f migrations/001_initial.sql
```

### 3. Configure Environment
```bash
cp .env.example .env
```

Edit `.env` - at minimum set:
```
DB_PASSWORD=your_postgres_password
JWT_SECRET=your_random_secret_here
CORS_ORIGIN=http://localhost:3000
```

### 4. Seed Database
```bash
npm run seed
```

This creates admin user: `admin` / `admin123`

### 5. Start Server
```bash
npm run dev
```

Visit `http://localhost:3000/health` to verify it's running.

## First Login

```bash
curl -X POST http://localhost:3000/api/jornada/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

Response includes `accessToken` and `refreshToken`.

## Next Steps

1. Read `SETUP.md` for detailed instructions
2. See `README.md` for complete API documentation
3. Review `.env.example` for all configuration options
4. Check `src/` for TypeScript type definitions
5. Connect your React frontend using the access token

## Key Files

| File | Purpose |
|------|---------|
| `src/index.ts` | Express server entry point |
| `src/routes/*` | API endpoint handlers |
| `src/middleware/*` | Authentication and validation |
| `migrations/001_initial.sql` | Database schema |
| `scripts/seed.ts` | Initial data setup |
| `.env` | Configuration (after copying from .env.example) |

## Troubleshooting

**Port 3000 in use?** Change in `.env`: `PORT=3001`

**Database connection error?** Check `.env` DB credentials match PostgreSQL setup.

**CORS error from frontend?** Add frontend URL to `.env`: `CORS_ORIGIN=http://your-frontend-url`

**More help?** See SETUP.md or README.md

## Available Commands

```bash
npm run dev          # Development server
npm run build        # Compile TypeScript
npm start           # Production server
npm run typecheck   # Type checking
npm run seed        # Seed database
```

## Architecture Overview

```
Client (React PWA)
    ↓
Express Server (Node.js)
    ↓
PostgreSQL Database
    ↓
Google Gemini AI (optional, for features)
```

The backend provides REST API endpoints that the frontend calls via HTTP.

All API responses follow this format:
```json
{
  "data": { /* actual response */ },
  "meta": { /* pagination info */ }
}
```

## Environment Variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `PORT` | 3000 | Server port |
| `DB_HOST` | localhost | PostgreSQL host |
| `DB_NAME` | jornadavip | Database name |
| `JWT_SECRET` | required | Token signing secret |
| `CORS_ORIGIN` | required | Frontend URL(s) |

See `.env.example` for complete list.

## Need More?

- **Full Setup Guide**: `SETUP.md`
- **API Reference**: `README.md`
- **Implementation Details**: `BACKEND_SUMMARY.md`

You're ready to build!
