# JornadaVip Backend API

A production-ready Node.js + Express + PostgreSQL REST API for the JornadaVip patient journey app used by Vip Estetic clinic in Fortaleza/CE.

## Features

- User authentication (Admin login + OAuth patient login)
- Patient management and CRUD operations
- Anamnesis (patient health history) tracking
- Reminder system for consultations and treatments
- Campaign management and tracking
- Patient evolution/progress diary with photo support
- Reward points and referral system
- Analytics and engagement tracking
- AI-powered patient summaries via Google Gemini
- Webhook configuration for integrations
- JWT-based authentication with refresh tokens
- Comprehensive error handling and validation
- PostgreSQL connection pooling
- CORS support for frontend integration

## Tech Stack

- **Runtime**: Node.js 20+
- **Language**: TypeScript
- **Framework**: Express 4
- **Database**: PostgreSQL 12+
- **Authentication**: JWT (jsonwebtoken)
- **Password Hashing**: bcryptjs
- **AI Integration**: Google Generative AI (Gemini)
- **Security**: Helmet, CORS

## Installation

### Prerequisites

- Node.js 20 or higher
- PostgreSQL 12 or higher
- npm or yarn

### Setup Steps

1. Clone or download the backend folder
2. Install dependencies:

```bash
npm install
```

3. Create a `.env` file based on `.env.example`:

```bash
cp .env.example .env
```

4. Configure your environment variables in `.env`:

```
NODE_ENV=development
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jornadavip
DB_USER=postgres
DB_PASSWORD=your_password
JWT_SECRET=your_jwt_secret
GEMINI_API_KEY=your_gemini_api_key
CORS_ORIGIN=http://localhost:3000
```

5. Create the PostgreSQL database:

```bash
createdb jornadavip
```

6. Run migrations to create tables:

```bash
psql -U postgres -d jornadavip -f migrations/001_initial.sql
```

7. Seed the database with initial data:

```bash
npm run seed
```

8. Start the development server:

```bash
npm run dev
```

The API will be available at `http://localhost:3000`.

## Available Scripts

- `npm run dev` - Start development server with ts-node
- `npm run build` - Compile TypeScript to JavaScript
- `npm start` - Start production server
- `npm run typecheck` - Check TypeScript types without compiling
- `npm run seed` - Seed database with initial admin user and sample data

## API Endpoints

### Authentication

- `POST /api/jornada/auth/login` - Admin login (username/password)
- `POST /api/jornada/auth/patient-login` - OAuth patient login (Google/Apple)
- `POST /api/jornada/auth/refresh` - Refresh JWT token
- `POST /api/jornada/auth/logout` - Revoke all user tokens

### Patients

- `GET /api/jornada/patients` - List all patients (admin only)
- `GET /api/jornada/patients/:id` - Get patient by ID
- `POST /api/jornada/patients` - Create new patient (admin only)
- `PUT /api/jornada/patients/:id` - Update patient
- `DELETE /api/jornada/patients/:id` - Delete patient (admin only)

### Anamnesis

- `GET /api/jornada/patients/:id/anamnesis` - Get patient health history
- `POST /api/jornada/patients/:id/anamnesis` - Save/update anamnesis

### Reminders

- `GET /api/jornada/patients/:id/reminders` - Get patient reminders
- `POST /api/jornada/patients/:id/reminders` - Create reminder (admin only)
- `PUT /api/jornada/patients/:id/reminders/:rid/read` - Mark reminder as read

### Campaigns

- `GET /api/jornada/campaigns` - List all campaigns (admin only)
- `POST /api/jornada/campaigns` - Create campaign (admin only)
- `GET /api/jornada/campaigns/pending/:patientId` - Get pending campaigns for patient
- `POST /api/jornada/campaigns/:id/read` - Mark campaign as read

### Evolution

- `GET /api/jornada/patients/:id/evolution` - Get evolution entries
- `POST /api/jornada/patients/:id/evolution` - Create evolution entry (photo diary)
- `DELETE /api/jornada/patients/:id/evolution/:eid` - Delete evolution entry

### Rewards

- `GET /api/jornada/patients/:id/rewards` - Get patient rewards/points
- `POST /api/jornada/patients/:id/rewards/referral` - Record referral

### Analytics

- `POST /api/jornada/analytics/event` - Track analytics event
- `POST /api/jornada/analytics/session` - Track session
- `GET /api/jornada/analytics/engagement/:patientId` - Get engagement data

### Webhooks

- `GET /api/jornada/webhooks` - Get webhook configs (admin only)
- `PUT /api/jornada/webhooks` - Update webhook config (admin only)

### AI Services

- `POST /api/ai/chat` - Chat with AI assistant
- `POST /api/ai/summary` - Generate AI patient summary

## Authentication

The API uses JWT (JSON Web Tokens) for authentication:

1. Admin users login with username/password
2. Patients login with OAuth (Google/Apple) or receive token from admin
3. Both receive an access token (24h expiry) and refresh token (7d expiry)
4. Access tokens are included in `Authorization: Bearer <token>` header
5. Refresh tokens are used to get new access tokens without logging in again

### Protected Routes

- **Admin only**: `/patients`, `/campaigns` (create), `/reminders` (create), `/webhooks`
- **Authenticated**: All patient data endpoints require either admin or patient JWT
- **Patient-specific**: Patients can only access their own data unless they're admins

## Database Schema

The database includes the following main tables:

- `admin_users` - Admin accounts with roles
- `patients` - Patient profiles
- `anamnesis` - Patient health/medical history
- `reminders` - Consultation and medication reminders
- `campaigns` - Marketing campaigns
- `campaign_reads` - Campaign engagement tracking
- `evolution_entries` - Patient progress photos and notes
- `rewards` - Patient loyalty points
- `analytics_events` - User behavior analytics
- `webhook_configs` - Webhook integrations
- `refresh_tokens` - Session management

## Error Handling

All endpoints return consistent error responses:

```json
{
  "error": "Error message",
  "details": {
    "field": "error description"
  }
}
```

Common error codes:
- `400` - Bad Request (validation errors)
- `401` - Unauthorized (missing/invalid authentication)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found
- `409` - Conflict (duplicate data)
- `500` - Internal Server Error

## Response Format

Success responses follow this format:

```json
{
  "data": {...},
  "meta": {
    "total": 100,
    "limit": 20,
    "offset": 0
  }
}
```

## Environment Variables

See `.env.example` for all available configuration options:

- **Server**: `NODE_ENV`, `PORT`, `API_URL`
- **Database**: `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_POOL_MIN`, `DB_POOL_MAX`
- **JWT**: `JWT_SECRET`, `JWT_EXPIRY`, `JWT_REFRESH_SECRET`, `JWT_REFRESH_EXPIRY`
- **CORS**: `CORS_ORIGIN` (comma-separated origins)
- **AI**: `GEMINI_API_KEY`
- **OAuth**: `GOOGLE_OAUTH_CLIENT_ID`, `GOOGLE_OAUTH_CLIENT_SECRET`, etc.
- **File Upload**: `MAX_FILE_SIZE`, `UPLOAD_DIR`

## Production Deployment

For production deployment:

1. Set `NODE_ENV=production`
2. Use strong `JWT_SECRET` and `JWT_REFRESH_SECRET` values
3. Configure PostgreSQL with proper backups and replication
4. Use HTTPS with a valid SSL certificate
5. Set appropriate `CORS_ORIGIN` values
6. Configure rate limiting and request size limits
7. Set up monitoring and logging
8. Use environment-specific `.env` files
9. Run `npm run build` and serve `dist/` folder
10. Keep dependencies updated

## License

MIT

## Support

For issues or questions, contact the development team.
