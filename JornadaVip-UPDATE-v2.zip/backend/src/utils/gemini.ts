import { GoogleGenerativeAI } from '@google/generative-ai';
import config from '../config';

let genAI: GoogleGenerativeAI | null = null;

export const initializeGemini = (): void => {
  if (!config.gemini.apiKey) {
    console.warn('GEMINI_API_KEY not configured. AI features will be limited.');
    return;
  }
  genAI = new GoogleGenerativeAI(config.gemini.apiKey);
};

export const generateContent = async (prompt: string): Promise<string> => {
  if (!genAI) {
    throw new Error('Gemini API not initialized. Set GEMINI_API_KEY in environment.');
  }

  const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
};

export const generatePatientSummary = async (patientData: {
  name: string;
  objective: string;
  style: string;
  commPreference: string;
  healthHistory?: string;
  pastProcedures?: string;
}): Promise<string> => {
  if (!genAI) {
    throw new Error('Gemini API not initialized.');
  }

  const prompt = `
Você é um especialista em estética clínica. Gere um resumo personalizado de atendimento para a seguinte paciente:

Nome: ${patientData.name}
Objetivo estético: ${patientData.objective}
Estilo desejado: ${patientData.style} (natural/marcante/discreto)
Preferência de comunicação: ${patientData.commPreference} (técnico/simples)
${patientData.healthHistory ? `Histórico de saúde: ${patientData.healthHistory}` : ''}
${patientData.pastProcedures ? `Procedimentos anteriores: ${patientData.pastProcedures}` : ''}

Por favor, gere:
1. Um resumo executivo do perfil da paciente
2. Recomendações de procedimentos alinhados com seus objetivos
3. Considerações de segurança baseado no histórico
4. Sugestões de comunicação personalizada

Mantenha um tom profissional, acolhedor e sem jargão clínico excessivo.
  `;

  const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
};

export const chatWithAssistant = async (messages: Array<{ role: 'user' | 'assistant'; content: string }>): Promise<string> => {
  if (!genAI) {
    throw new Error('Gemini API not initialized.');
  }

  const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
  const lastMessage = messages[messages.length - 1];

  // For now, Gemini doesn't support multi-turn conversation in the same way
  // We'll use the full message history as context
  const context = messages.map(m => `${m.role === 'user' ? 'Paciente' : 'Assistente'}: ${m.content}`).join('\n');

  const prompt = `Você é um assistente de estética clínica. Mantenha um tom acolhedor, profissional e empático. Nunca forneça diagnósticos médicos, apenas informações educacionais sobre procedimentos estéticos.

Histórico da conversa:
${context}

Responda à última mensagem de forma clara, concisa e apropriada para pacientes de clínicas de estética.`;

  const result = await model.generateContent(prompt);
  const response = await result.response;
  return response.text();
};

export default {
  initializeGemini,
  generateContent,
  generatePatientSummary,
  chatWithAssistant,
};
