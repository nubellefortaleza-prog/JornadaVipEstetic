import jwt from 'jsonwebtoken';
import config from '../config';
import { query } from '../database';

export interface TokenPayload {
  id: string;
  type: 'admin' | 'patient';
  role?: string;
}

export const generateToken = (payload: TokenPayload): string => {
  return jwt.sign(payload, config.jwt.secret, {
    expiresIn: config.jwt.expiry,
  });
};

export const generateRefreshToken = (
  userId: string,
  userType: 'admin' | 'patient'
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const token = jwt.sign(
      { id: userId, type: userType },
      config.jwt.refreshSecret,
      { expiresIn: config.jwt.refreshExpiry }
    );

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

    query(
      `INSERT INTO refresh_tokens (user_id, user_type, token, expires_at)
       VALUES ($1, $2, $3, $4)`,
      [userId, userType, token, expiresAt]
    )
      .then(() => resolve(token))
      .catch(reject);
  });
};

export const verifyToken = (token: string): TokenPayload | null => {
  try {
    return jwt.verify(token, config.jwt.secret) as TokenPayload;
  } catch (error) {
    return null;
  }
};

export const verifyRefreshToken = (token: string): TokenPayload | null => {
  try {
    return jwt.verify(token, config.jwt.refreshSecret) as TokenPayload;
  } catch (error) {
    return null;
  }
};

export const validateRefreshToken = async (
  token: string,
  userId: string,
  userType: 'admin' | 'patient'
): Promise<boolean> => {
  try {
    const result = await query(
      `SELECT * FROM refresh_tokens
       WHERE user_id = $1 AND user_type = $2 AND token = $3 AND expires_at > NOW()`,
      [userId, userType, token]
    );
    return result.rows.length > 0;
  } catch (error) {
    return false;
  }
};

export const revokeRefreshToken = async (token: string): Promise<void> => {
  await query(`DELETE FROM refresh_tokens WHERE token = $1`, [token]);
};

export const revokeUserTokens = async (
  userId: string,
  userType: 'admin' | 'patient'
): Promise<void> => {
  await query(
    `DELETE FROM refresh_tokens WHERE user_id = $1 AND user_type = $2`,
    [userId, userType]
  );
};

export default {
  generateToken,
  generateRefreshToken,
  verifyToken,
  verifyRefreshToken,
  validateRefreshToken,
  revokeRefreshToken,
  revokeUserTokens,
};
