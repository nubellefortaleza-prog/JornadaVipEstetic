import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requireAdmin } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface WebhookConfigRequest {
  url: string;
  name?: string;
  active?: boolean;
  events?: string[];
}

// Get webhook configs (admin only)
router.get(
  '/webhooks',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const result = await query(
      `SELECT id, url, name, active, events, created_at FROM webhook_configs ORDER BY created_at DESC`
    );

    res.json({
      data: result.rows,
      meta: {
        total: result.rows.length,
      },
    });
  })
);

// Update webhook config (admin only)
router.put(
  '/webhooks',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { id, url, name, active, events } = req.body as WebhookConfigRequest & { id: string };

    if (!id) {
      throw createApiError('Webhook ID is required', 400);
    }

    if (!url) {
      throw createApiError('Webhook URL is required', 400);
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      throw createApiError('Invalid webhook URL format', 400);
    }

    const updates: string[] = [];
    const values: any[] = [];
    let paramCount = 1;

    if (url !== undefined) {
      updates.push(`url = $${paramCount++}`);
      values.push(url);
    }
    if (name !== undefined) {
      updates.push(`name = $${paramCount++}`);
      values.push(name || null);
    }
    if (active !== undefined) {
      updates.push(`active = $${paramCount++}`);
      values.push(active);
    }
    if (events !== undefined) {
      updates.push(`events = $${paramCount++}`);
      values.push(events && events.length > 0 ? events : []);
    }

    if (updates.length === 0) {
      throw createApiError('No fields to update', 400);
    }

    values.push(id);

    const result = await query(
      `UPDATE webhook_configs SET ${updates.join(', ')} WHERE id = $${paramCount}
       RETURNING id, url, name, active, events, created_at`,
      values
    );

    if (result.rows.length === 0) {
      throw createApiError('Webhook config not found', 404);
    }

    res.json({
      data: result.rows[0],
    });
  })
);

// Create webhook config (admin only)
router.post(
  '/webhooks',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { url, name, active, events } = req.body as WebhookConfigRequest;

    if (!url) {
      throw createApiError('Webhook URL is required', 400);
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      throw createApiError('Invalid webhook URL format', 400);
    }

    const result = await query(
      `INSERT INTO webhook_configs (url, name, active, events)
       VALUES ($1, $2, $3, $4)
       RETURNING id, url, name, active, events, created_at`,
      [url, name || null, active !== false, events && events.length > 0 ? events : []]
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Delete webhook config (admin only)
router.delete(
  '/webhooks/:id',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    const result = await query(
      `DELETE FROM webhook_configs WHERE id = $1 RETURNING id`,
      [id]
    );

    if (result.rows.length === 0) {
      throw createApiError('Webhook config not found', 404);
    }

    res.json({
      data: {
        message: 'Webhook config deleted successfully',
        id: result.rows[0].id,
      },
    });
  })
);

export default router;
