import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requireAdmin, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface CampaignCreateRequest {
  title: string;
  message?: string;
  imageUrl?: string;
  ctaLabel?: string;
  ctaUrl?: string;
  targetPatientIds?: string | string[];
  scheduledAt?: string;
}

// Get all campaigns (admin only)
router.get(
  '/campaigns',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const offset = parseInt(req.query.offset as string) || 0;

    const countResult = await query('SELECT COUNT(*) as total FROM campaigns');
    const total = parseInt(countResult.rows[0].total, 10);

    const result = await query(
      `SELECT id, title, message, image_url, cta_label, cta_url, target_patient_ids, scheduled_at, created_at
       FROM campaigns
       ORDER BY created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    res.json({
      data: result.rows,
      meta: {
        total,
        limit,
        offset,
      },
    });
  })
);

// Create campaign (admin only)
router.post(
  '/campaigns',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { title, message, imageUrl, ctaLabel, ctaUrl, targetPatientIds, scheduledAt } = req.body as CampaignCreateRequest;

    if (!title) {
      throw createApiError('Campaign title is required', 400);
    }

    let targetIds = 'all';
    if (targetPatientIds) {
      if (Array.isArray(targetPatientIds)) {
        targetIds = JSON.stringify(targetPatientIds);
      } else if (targetPatientIds !== 'all') {
        targetIds = targetPatientIds;
      }
    }

    const result = await query(
      `INSERT INTO campaigns (title, message, image_url, cta_label, cta_url, target_patient_ids, scheduled_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, title, message, image_url, cta_label, cta_url, target_patient_ids, scheduled_at, created_at`,
      [title, message || null, imageUrl || null, ctaLabel || null, ctaUrl || null, targetIds, scheduledAt || null]
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Get pending campaigns for patient
router.get(
  '/campaigns/pending/:patientId',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { patientId } = req.params;

    // Patients can only view their own campaigns unless admin
    if (req.user?.type === 'patient' && req.user.id !== patientId) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `SELECT c.id, c.title, c.message, c.image_url, c.cta_label, c.cta_url, c.created_at
       FROM campaigns c
       LEFT JOIN campaign_reads cr ON c.id = cr.campaign_id AND cr.patient_id = $1
       WHERE cr.patient_id IS NULL
       AND (c.target_patient_ids = 'all'
            OR c.target_patient_ids::jsonb @> $2::jsonb
            OR c.target_patient_ids = $3)
       AND (c.scheduled_at IS NULL OR c.scheduled_at <= NOW())
       ORDER BY c.created_at DESC`,
      [patientId, JSON.stringify([patientId]), patientId]
    );

    res.json({
      data: result.rows,
      meta: {
        total: result.rows.length,
      },
    });
  })
);

// Mark campaign as read by patient
router.post(
  '/campaigns/:id/read',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    if (!req.user) {
      throw createApiError('Not authenticated', 401);
    }

    // Check if campaign exists
    const campaignCheck = await query('SELECT id FROM campaigns WHERE id = $1', [id]);
    if (campaignCheck.rows.length === 0) {
      throw createApiError('Campaign not found', 404);
    }

    // Insert or ignore (upsert)
    await query(
      `INSERT INTO campaign_reads (campaign_id, patient_id, read_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (campaign_id, patient_id) DO NOTHING`,
      [id, req.user.id]
    );

    res.json({
      data: {
        message: 'Campaign marked as read',
      },
    });
  })
);

export default router;
