import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface AnamnesisRequest {
  healthGeneral?: string;
  allergies?: string;
  medications?: string;
  pregnancy?: boolean;
  pastProcedures?: string;
  expectedResult?: string;
  habitsSun?: string;
  habitsSleep?: string;
  habitsSmoking?: boolean;
  habitsSkinecare?: string;
}

// Get patient anamnesis
router.get(
  '/patients/:id/anamnesis',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    // Patients can only view their own anamnesis unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `SELECT id, patient_id, health_general, allergies, medications, pregnancy, past_procedures, expected_result,
              habits_sun, habits_sleep, habits_smoking, habits_skincare, created_at, updated_at
       FROM anamnesis
       WHERE patient_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      res.json({
        data: null,
      });
      return;
    }

    res.json({
      data: result.rows[0],
    });
  })
);

// Save/update anamnesis
router.post(
  '/patients/:id/anamnesis',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const {
      healthGeneral,
      allergies,
      medications,
      pregnancy,
      pastProcedures,
      expectedResult,
      habitsSun,
      habitsSleep,
      habitsSmoking,
      habitsSkinecare,
    } = req.body as AnamnesisRequest;

    // Patients can only update their own anamnesis unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    // Check if patient exists
    const patientCheck = await query('SELECT id FROM patients WHERE id = $1', [id]);
    if (patientCheck.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    // Check if anamnesis exists
    const existingCheck = await query('SELECT id FROM anamnesis WHERE patient_id = $1', [id]);

    let result;
    if (existingCheck.rows.length === 0) {
      // Create new anamnesis
      result = await query(
        `INSERT INTO anamnesis (patient_id, health_general, allergies, medications, pregnancy, past_procedures, expected_result, habits_sun, habits_sleep, habits_smoking, habits_skincare)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         RETURNING id, patient_id, health_general, allergies, medications, pregnancy, past_procedures, expected_result, habits_sun, habits_sleep, habits_smoking, habits_skincare, created_at, updated_at`,
        [id, healthGeneral || null, allergies || null, medications || null, pregnancy || false, pastProcedures || null, expectedResult || null, habitsSun || null, habitsSleep || null, habitsSmoking || false, habitsSkinecare || null]
      );
    } else {
      // Update existing anamnesis
      result = await query(
        `UPDATE anamnesis SET
         health_general = COALESCE($1, health_general),
         allergies = COALESCE($2, allergies),
         medications = COALESCE($3, medications),
         pregnancy = COALESCE($4, pregnancy),
         past_procedures = COALESCE($5, past_procedures),
         expected_result = COALESCE($6, expected_result),
         habits_sun = COALESCE($7, habits_sun),
         habits_sleep = COALESCE($8, habits_sleep),
         habits_smoking = COALESCE($9, habits_smoking),
         habits_skincare = COALESCE($10, habits_skincare),
         updated_at = NOW()
         WHERE patient_id = $11
         RETURNING id, patient_id, health_general, allergies, medications, pregnancy, past_procedures, expected_result, habits_sun, habits_sleep, habits_smoking, habits_skincare, created_at, updated_at`,
        [healthGeneral, allergies, medications, pregnancy, pastProcedures, expectedResult, habitsSun, habitsSleep, habitsSmoking, habitsSkinecare, id]
      );
    }

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

export default router;
