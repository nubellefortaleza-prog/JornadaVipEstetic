import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requireAdmin, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface AnalyticsEventRequest {
  eventType: string;
  eventData?: Record<string, any>;
}

interface AnalyticsSessionRequest {
  sessionDuration?: number;
  deviceType?: string;
  userAgent?: string;
}

// Track event
router.post(
  '/analytics/event',
  asyncHandler(authenticateToken),
  asyncHandler(async (req, res) => {
    const { eventType, eventData } = req.body as AnalyticsEventRequest;

    if (!eventType) {
      throw createApiError('Event type is required', 400);
    }

    const patientId = req.user?.type === 'patient' ? req.user.id : null;

    const result = await query(
      `INSERT INTO analytics_events (patient_id, event_type, event_data)
       VALUES ($1, $2, $3)
       RETURNING id, patient_id, event_type, event_data, created_at`,
      [patientId, eventType, eventData ? JSON.stringify(eventData) : null]
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Track session
router.post(
  '/analytics/session',
  asyncHandler(authenticateToken),
  asyncHandler(async (req, res) => {
    const { sessionDuration, deviceType, userAgent } = req.body as AnalyticsSessionRequest;

    const patientId = req.user?.type === 'patient' ? req.user.id : null;
    const eventData = {
      sessionDuration: sessionDuration || 0,
      deviceType: deviceType || 'unknown',
      userAgent: userAgent || req.headers['user-agent'] || null,
    };

    const result = await query(
      `INSERT INTO analytics_events (patient_id, event_type, event_data)
       VALUES ($1, $2, $3)
       RETURNING id, patient_id, event_type, event_data, created_at`,
      [patientId, 'session_end', JSON.stringify(eventData)]
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Get engagement data for patient
router.get(
  '/analytics/engagement/:patientId',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { patientId } = req.params;

    // Patients can only view their own engagement unless admin
    if (req.user?.type === 'patient' && req.user.id !== patientId) {
      throw createApiError('Access denied', 403);
    }

    // Get total events
    const totalEventsResult = await query(
      `SELECT COUNT(*) as total FROM analytics_events WHERE patient_id = $1`,
      [patientId]
    );

    // Get events by type
    const eventsByTypeResult = await query(
      `SELECT event_type, COUNT(*) as count
       FROM analytics_events
       WHERE patient_id = $1
       GROUP BY event_type
       ORDER BY count DESC`,
      [patientId]
    );

    // Get engagement over time (last 30 days)
    const engagementTimeResult = await query(
      `SELECT DATE(created_at) as date, COUNT(*) as event_count
       FROM analytics_events
       WHERE patient_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
       GROUP BY DATE(created_at)
       ORDER BY date DESC`,
      [patientId]
    );

    // Get session info
    const sessionResult = await query(
      `SELECT COUNT(*) as total_sessions, AVG((event_data->>'sessionDuration')::integer) as avg_duration
       FROM analytics_events
       WHERE patient_id = $1 AND event_type = 'session_end'`,
      [patientId]
    );

    res.json({
      data: {
        totalEvents: parseInt(totalEventsResult.rows[0].total, 10),
        eventsByType: eventsByTypeResult.rows,
        engagementByDate: engagementTimeResult.rows,
        sessions: {
          total: parseInt(sessionResult.rows[0].total_sessions || 0, 10),
          avgDuration: sessionResult.rows[0].avg_duration ? parseInt(sessionResult.rows[0].avg_duration, 10) : 0,
        },
      },
    });
  })
);

export default router;
