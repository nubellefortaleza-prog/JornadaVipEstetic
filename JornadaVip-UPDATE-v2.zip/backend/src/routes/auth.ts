import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { query } from '../database';
import { generateToken, generateRefreshToken, verifyRefreshToken, revokeUserTokens } from '../utils/jwt';
import { asyncHandler, authenticateToken, requireAdmin } from '../middleware/auth';
import { validate, validateEmail } from '../middleware/validation';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface AdminLoginRequest {
  username: string;
  password: string;
}

interface PatientOAuthRequest {
  provider: 'google' | 'apple';
  token: string;
  name?: string;
  email?: string;
  photoUrl?: string;
}

interface RefreshTokenRequest {
  refreshToken: string;
}

// Admin login with username/password
router.post(
  '/auth/login',
  asyncHandler(async (req, res) => {
    const { username, password } = req.body as AdminLoginRequest;

    if (!username || !password) {
      throw createApiError('Username and password required', 400);
    }

    const result = await query(
      'SELECT id, username, password_hash, role FROM admin_users WHERE username = $1',
      [username]
    );

    if (result.rows.length === 0) {
      throw createApiError('Invalid credentials', 401);
    }

    const admin = result.rows[0];
    const passwordMatch = await bcrypt.compare(password, admin.password_hash);

    if (!passwordMatch) {
      throw createApiError('Invalid credentials', 401);
    }

    const accessToken = generateToken({ id: admin.id, type: 'admin', role: admin.role });
    const refreshToken = await generateRefreshToken(admin.id, 'admin');

    res.json({
      data: {
        accessToken,
        refreshToken,
        user: {
          id: admin.id,
          username: admin.username,
          role: admin.role,
        },
      },
    });
  })
);

// Patient OAuth login (Google/Apple)
router.post(
  '/auth/patient-login',
  asyncHandler(async (req, res) => {
    const { provider, token, name, email, photoUrl } = req.body as PatientOAuthRequest;

    if (!provider || !token) {
      throw createApiError('Provider and token required', 400);
    }

    if (!['google', 'apple'].includes(provider)) {
      throw createApiError('Invalid OAuth provider', 400);
    }

    // In production, verify the token with the OAuth provider
    // For now, we'll accept it as-is (implement proper verification in production)

    let patient = null;
    const oauthId = `${provider}_${token}`;

    // Try to find existing patient by OAuth ID
    let result = await query(
      'SELECT id FROM patients WHERE oauth_provider = $1 AND oauth_id = $2',
      [provider, token]
    );

    if (result.rows.length > 0) {
      patient = result.rows[0];
    } else if (email) {
      // Try to find by email
      result = await query('SELECT id FROM patients WHERE email = $1', [email]);
      if (result.rows.length > 0) {
        patient = result.rows[0];
        // Update with OAuth info
        await query(
          'UPDATE patients SET oauth_provider = $1, oauth_id = $2 WHERE id = $3',
          [provider, token, patient.id]
        );
      }
    }

    // Create new patient if not found
    if (!patient) {
      result = await query(
        `INSERT INTO patients (name, email, oauth_provider, oauth_id, photo_url, comm_preference)
         VALUES ($1, $2, $3, $4, $5, 'simples')
         RETURNING id`,
        [name || 'Paciente', email || null, provider, token, photoUrl || null]
      );
      patient = result.rows[0];
    }

    const accessToken = generateToken({ id: patient.id, type: 'patient' });
    const refreshToken = await generateRefreshToken(patient.id, 'patient');

    res.json({
      data: {
        accessToken,
        refreshToken,
        user: {
          id: patient.id,
          type: 'patient',
        },
      },
    });
  })
);

// Refresh token
router.post(
  '/auth/refresh',
  asyncHandler(async (req, res) => {
    const { refreshToken } = req.body as RefreshTokenRequest;

    if (!refreshToken) {
      throw createApiError('Refresh token required', 400);
    }

    const payload = verifyRefreshToken(refreshToken);
    if (!payload) {
      throw createApiError('Invalid or expired refresh token', 401);
    }

    // Verify token exists in database
    const result = await query(
      `SELECT user_type FROM refresh_tokens
       WHERE user_id = $1 AND token = $2 AND expires_at > NOW()`,
      [payload.id, refreshToken]
    );

    if (result.rows.length === 0) {
      throw createApiError('Refresh token not found or expired', 401);
    }

    const userType = result.rows[0].user_type;
    const newAccessToken = generateToken({ id: payload.id, type: userType as 'admin' | 'patient' });

    res.json({
      data: {
        accessToken: newAccessToken,
      },
    });
  })
);

// Logout
router.post(
  '/auth/logout',
  asyncHandler(authenticateToken),
  asyncHandler(async (req, res) => {
    if (!req.user) {
      throw createApiError('Not authenticated', 401);
    }

    await revokeUserTokens(req.user.id, req.user.type);

    res.json({
      data: {
        message: 'Logged out successfully',
      },
    });
  })
);

export default router;
