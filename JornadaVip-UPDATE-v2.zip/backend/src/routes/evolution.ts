import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface EvolutionEntryRequest {
  note?: string;
  photoUrl?: string;
}

// Get evolution entries for patient
router.get(
  '/patients/:id/evolution',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    // Patients can only view their own evolution unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `SELECT id, patient_id, note, photo_url, created_at
       FROM evolution_entries
       WHERE patient_id = $1
       ORDER BY created_at DESC`,
      [id]
    );

    res.json({
      data: result.rows,
      meta: {
        total: result.rows.length,
      },
    });
  })
);

// Create evolution entry
router.post(
  '/patients/:id/evolution',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { note, photoUrl } = req.body as EvolutionEntryRequest;

    // Patients can only create their own evolution unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    // Check if patient exists
    const patientCheck = await query('SELECT id FROM patients WHERE id = $1', [id]);
    if (patientCheck.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    const result = await query(
      `INSERT INTO evolution_entries (patient_id, note, photo_url)
       VALUES ($1, $2, $3)
       RETURNING id, patient_id, note, photo_url, created_at`,
      [id, note || null, photoUrl || null]
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Delete evolution entry
router.delete(
  '/patients/:id/evolution/:eid',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id, eid } = req.params;

    // Patients can only delete their own evolution unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `DELETE FROM evolution_entries WHERE id = $1 AND patient_id = $2 RETURNING id`,
      [eid, id]
    );

    if (result.rows.length === 0) {
      throw createApiError('Evolution entry not found', 404);
    }

    res.json({
      data: {
        message: 'Evolution entry deleted successfully',
        id: result.rows[0].id,
      },
    });
  })
);

export default router;
