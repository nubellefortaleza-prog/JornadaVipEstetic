import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

// Get patient rewards/points
router.get(
  '/patients/:id/rewards',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    // Patients can only view their own rewards unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    let result = await query(
      `SELECT id, patient_id, total, referrals_count, registered_count, level, updated_at
       FROM rewards
       WHERE patient_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      // Create default rewards record
      result = await query(
        `INSERT INTO rewards (patient_id, total, referrals_count, registered_count, level)
         VALUES ($1, 0, 0, 0, 'Iniciante')
         RETURNING id, patient_id, total, referrals_count, registered_count, level, updated_at`,
        [id]
      );
    }

    res.json({
      data: result.rows[0],
    });
  })
);

// Record referral
router.post(
  '/patients/:id/rewards/referral',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { referredPatientId } = req.body;

    // Patients can only record their own referrals unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    if (!referredPatientId) {
      throw createApiError('Referred patient ID is required', 400);
    }

    // Check if patient exists
    const patientCheck = await query('SELECT id FROM patients WHERE id = $1', [id]);
    if (patientCheck.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    // Check if referred patient exists
    const referredCheck = await query('SELECT id FROM patients WHERE id = $1', [referredPatientId]);
    if (referredCheck.rows.length === 0) {
      throw createApiError('Referred patient not found', 404);
    }

    // Get or create rewards record
    let result = await query(
      `SELECT id FROM rewards WHERE patient_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      await query(
        `INSERT INTO rewards (patient_id, total, referrals_count, registered_count, level)
         VALUES ($1, 0, 0, 0, 'Iniciante')`,
        [id]
      );
    }

    // Update rewards (add points for referral: 50 points)
    const referralPoints = 50;
    result = await query(
      `UPDATE rewards
       SET total = total + $1,
           referrals_count = referrals_count + 1,
           level = CASE
             WHEN total + $1 >= 500 THEN 'Premium'
             WHEN total + $1 >= 200 THEN 'Avançado'
             ELSE 'Iniciante'
           END,
           updated_at = NOW()
       WHERE patient_id = $2
       RETURNING id, patient_id, total, referrals_count, registered_count, level, updated_at`,
      [referralPoints, id]
    );

    res.status(201).json({
      data: {
        rewards: result.rows[0],
        pointsAdded: referralPoints,
        message: 'Referral recorded successfully',
      },
    });
  })
);

export default router;
