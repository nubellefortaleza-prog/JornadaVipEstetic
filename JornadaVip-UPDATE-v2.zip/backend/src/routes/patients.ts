import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requireAdmin, requirePatient } from '../middleware/auth';
import { validate, validateEmail, validateCPF, validatePhone } from '../middleware/validation';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface PatientCreateRequest {
  name: string;
  phone?: string;
  cpf?: string;
  email?: string;
  birthDate?: string;
  city?: string;
  objective?: string;
  style?: 'natural' | 'marcante' | 'discreto';
  commPreference?: 'tecnico' | 'simples';
}

interface PatientUpdateRequest extends PatientCreateRequest {
  photoUrl?: string;
  moodCheckin?: string;
}

// Get all patients (admin only)
router.get(
  '/patients',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const offset = parseInt(req.query.offset as string) || 0;

    const countResult = await query('SELECT COUNT(*) as total FROM patients');
    const total = parseInt(countResult.rows[0].total, 10);

    const result = await query(
      `SELECT id, name, phone, email, city, objective, style, comm_preference, photo_url, mood_checkin, created_at, updated_at
       FROM patients
       ORDER BY created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    res.json({
      data: result.rows,
      meta: {
        total,
        limit,
        offset,
      },
    });
  })
);

// Get patient by ID
router.get(
  '/patients/:id',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    // Patients can only view their own data unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `SELECT id, name, phone, cpf, email, birth_date, city, objective, style, comm_preference, photo_url, mood_checkin, created_at, updated_at
       FROM patients
       WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    res.json({
      data: result.rows[0],
    });
  })
);

// Create patient
router.post(
  '/patients',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { name, phone, cpf, email, birthDate, city, objective, style, commPreference } = req.body as PatientCreateRequest;

    if (!name) {
      throw createApiError('Patient name is required', 400);
    }

    if (cpf && !validateCPF(cpf)) {
      throw createApiError('Invalid CPF format', 400);
    }

    if (email && !validateEmail(email)) {
      throw createApiError('Invalid email format', 400);
    }

    if (phone && !validatePhone(phone)) {
      throw createApiError('Invalid phone format', 400);
    }

    try {
      const result = await query(
        `INSERT INTO patients (name, phone, cpf, email, birth_date, city, objective, style, comm_preference)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         RETURNING id, name, phone, cpf, email, birth_date, city, objective, style, comm_preference, created_at, updated_at`,
        [name, phone || null, cpf || null, email || null, birthDate || null, city || null, objective || null, style || 'natural', commPreference || 'simples']
      );

      res.status(201).json({
        data: result.rows[0],
      });
    } catch (error: any) {
      if (error.code === '23505') {
        throw createApiError('Duplicate patient data (CPF or email already exists)', 409);
      }
      throw error;
    }
  })
);

// Update patient
router.put(
  '/patients/:id',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { name, phone, cpf, email, birthDate, city, objective, style, commPreference, photoUrl, moodCheckin } = req.body as PatientUpdateRequest;

    // Patients can only update their own data unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    // Validate inputs
    if (cpf && !validateCPF(cpf)) {
      throw createApiError('Invalid CPF format', 400);
    }

    if (email && !validateEmail(email)) {
      throw createApiError('Invalid email format', 400);
    }

    if (phone && !validatePhone(phone)) {
      throw createApiError('Invalid phone format', 400);
    }

    const updates: string[] = [];
    const values: any[] = [];
    let paramCount = 1;

    if (name !== undefined) {
      updates.push(`name = $${paramCount++}`);
      values.push(name);
    }
    if (phone !== undefined) {
      updates.push(`phone = $${paramCount++}`);
      values.push(phone || null);
    }
    if (cpf !== undefined) {
      updates.push(`cpf = $${paramCount++}`);
      values.push(cpf || null);
    }
    if (email !== undefined) {
      updates.push(`email = $${paramCount++}`);
      values.push(email || null);
    }
    if (birthDate !== undefined) {
      updates.push(`birth_date = $${paramCount++}`);
      values.push(birthDate || null);
    }
    if (city !== undefined) {
      updates.push(`city = $${paramCount++}`);
      values.push(city || null);
    }
    if (objective !== undefined) {
      updates.push(`objective = $${paramCount++}`);
      values.push(objective || null);
    }
    if (style !== undefined) {
      updates.push(`style = $${paramCount++}`);
      values.push(style || 'natural');
    }
    if (commPreference !== undefined) {
      updates.push(`comm_preference = $${paramCount++}`);
      values.push(commPreference || 'simples');
    }
    if (photoUrl !== undefined) {
      updates.push(`photo_url = $${paramCount++}`);
      values.push(photoUrl || null);
    }
    if (moodCheckin !== undefined) {
      updates.push(`mood_checkin = $${paramCount++}`);
      values.push(moodCheckin || null);
    }

    if (updates.length === 0) {
      throw createApiError('No fields to update', 400);
    }

    updates.push(`updated_at = NOW()`);
    values.push(id);

    try {
      const result = await query(
        `UPDATE patients SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING id, name, phone, cpf, email, birth_date, city, objective, style, comm_preference, photo_url, mood_checkin, created_at, updated_at`,
        values
      );

      if (result.rows.length === 0) {
        throw createApiError('Patient not found', 404);
      }

      res.json({
        data: result.rows[0],
      });
    } catch (error: any) {
      if (error.code === '23505') {
        throw createApiError('Duplicate patient data (CPF or email already exists)', 409);
      }
      throw error;
    }
  })
);

// Delete patient (admin only)
router.delete(
  '/patients/:id',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    const result = await query('DELETE FROM patients WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    res.json({
      data: {
        message: 'Patient deleted successfully',
        id: result.rows[0].id,
      },
    });
  })
);

export default router;
