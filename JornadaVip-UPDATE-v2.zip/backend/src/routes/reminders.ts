import { Router } from 'express';
import { query } from '../database';
import { asyncHandler, authenticateToken, requireAdmin, requirePatient } from '../middleware/auth';
import { createApiError } from '../middleware/errorHandler';

const router = Router();

interface ReminderCreateRequest {
  title: string;
  message?: string;
  date?: string;
  type?: 'consulta' | 'orientacao' | 'medicacao';
}

// Get patient reminders
router.get(
  '/patients/:id/reminders',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    // Patients can only view their own reminders unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `SELECT id, patient_id, title, message, date, type, read, created_at
       FROM reminders
       WHERE patient_id = $1
       ORDER BY date DESC, created_at DESC`,
      [id]
    );

    res.json({
      data: result.rows,
      meta: {
        total: result.rows.length,
      },
    });
  })
);

// Create reminder (admin only)
router.post(
  '/patients/:id/reminders',
  asyncHandler(authenticateToken),
  asyncHandler(requireAdmin),
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { title, message, date, type } = req.body as ReminderCreateRequest;

    if (!title) {
      throw createApiError('Reminder title is required', 400);
    }

    if (type && !['consulta', 'orientacao', 'medicacao'].includes(type)) {
      throw createApiError('Invalid reminder type', 400);
    }

    // Check if patient exists
    const patientCheck = await query('SELECT id FROM patients WHERE id = $1', [id]);
    if (patientCheck.rows.length === 0) {
      throw createApiError('Patient not found', 404);
    }

    const result = await query(
      `INSERT INTO reminders (patient_id, title, message, date, type)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, patient_id, title, message, date, type, read, created_at`,
      [id, title, message || null, date || null, type || 'consulta']
    );

    res.status(201).json({
      data: result.rows[0],
    });
  })
);

// Mark reminder as read
router.put(
  '/patients/:id/reminders/:rid/read',
  asyncHandler(authenticateToken),
  asyncHandler(requirePatient),
  asyncHandler(async (req, res) => {
    const { id, rid } = req.params;

    // Patients can only update their own reminders unless admin
    if (req.user?.type === 'patient' && req.user.id !== id) {
      throw createApiError('Access denied', 403);
    }

    const result = await query(
      `UPDATE reminders SET read = true WHERE id = $1 AND patient_id = $2
       RETURNING id, patient_id, title, message, date, type, read, created_at`,
      [rid, id]
    );

    if (result.rows.length === 0) {
      throw createApiError('Reminder not found', 404);
    }

    res.json({
      data: result.rows[0],
    });
  })
);

export default router;
