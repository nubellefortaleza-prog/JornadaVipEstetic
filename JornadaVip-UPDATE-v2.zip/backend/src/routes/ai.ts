import { Router } from 'express';
import { asyncHandler, authenticateToken } from '../middleware/auth';
import { chatWithAssistant, generatePatientSummary } from '../utils/gemini';
import { createApiError } from '../middleware/errorHandler';
import { query } from '../database';

const router = Router();

interface ChatRequest {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
}

interface SummaryRequest {
  patientId: string;
}

// Chat with AI assistant
router.post(
  '/ai/chat',
  asyncHandler(authenticateToken),
  asyncHandler(async (req, res) => {
    const { messages } = req.body as ChatRequest;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      throw createApiError('Messages array is required and must not be empty', 400);
    }

    // Validate message structure
    for (const message of messages) {
      if (!message.role || !message.content) {
        throw createApiError('Each message must have role and content', 400);
      }
      if (!['user', 'assistant'].includes(message.role)) {
        throw createApiError('Message role must be "user" or "assistant"', 400);
      }
    }

    try {
      const response = await chatWithAssistant(messages);

      res.json({
        data: {
          response,
          role: 'assistant',
        },
      });
    } catch (error: any) {
      console.error('Gemini API error:', error);
      throw createApiError('Failed to generate response from AI', 500, {
        originalError: error.message,
      });
    }
  })
);

// Generate patient summary via AI
router.post(
  '/ai/summary',
  asyncHandler(authenticateToken),
  asyncHandler(async (req, res) => {
    const { patientId } = req.body as SummaryRequest;

    if (!patientId) {
      throw createApiError('Patient ID is required', 400);
    }

    // Verify patient exists and user has access
    if (req.user?.type === 'patient' && req.user.id !== patientId) {
      throw createApiError('Access denied', 403);
    }

    try {
      // Fetch patient data
      const patientResult = await query(
        `SELECT name, objective, style, comm_preference FROM patients WHERE id = $1`,
        [patientId]
      );

      if (patientResult.rows.length === 0) {
        throw createApiError('Patient not found', 404);
      }

      const patient = patientResult.rows[0];

      // Fetch anamnesis data
      const anamnesisResult = await query(
        `SELECT health_general, past_procedures FROM anamnesis WHERE patient_id = $1`,
        [patientId]
      );

      const anamnesis = anamnesisResult.rows[0] || {};

      const summary = await generatePatientSummary({
        name: patient.name,
        objective: patient.objective,
        style: patient.style,
        commPreference: patient.comm_preference,
        healthHistory: anamnesis.health_general,
        pastProcedures: anamnesis.past_procedures,
      });

      res.json({
        data: {
          summary,
          patientId,
        },
      });
    } catch (error: any) {
      console.error('Gemini API error:', error);
      throw createApiError('Failed to generate patient summary', 500, {
        originalError: error.message,
      });
    }
  })
);

export default router;
