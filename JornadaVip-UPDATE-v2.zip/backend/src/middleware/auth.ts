import { Request, Response, NextFunction } from 'express';
import { verifyToken, TokenPayload } from '../utils/jwt';
import { createApiError } from './errorHandler';

declare global {
  namespace Express {
    interface Request {
      user?: TokenPayload;
    }
  }
}

export const authenticateToken = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    throw createApiError('Access token required', 401);
  }

  const payload = verifyToken(token);
  if (!payload) {
    throw createApiError('Invalid or expired token', 401);
  }

  req.user = payload;
  next();
};

export const requireAdmin = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  if (!req.user) {
    throw createApiError('Authentication required', 401);
  }

  if (req.user.type !== 'admin') {
    throw createApiError('Admin access required', 403);
  }

  next();
};

export const requirePatient = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  if (!req.user) {
    throw createApiError('Authentication required', 401);
  }

  if (req.user.type !== 'patient' && req.user.type !== 'admin') {
    throw createApiError('Patient access required', 403);
  }

  next();
};

export const optionalAuth = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token) {
    const payload = verifyToken(token);
    if (payload) {
      req.user = payload;
    }
  }

  next();
};

// Wrapper to handle async middleware
export const asyncHandler = (fn: Function) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

export default {
  authenticateToken,
  requireAdmin,
  requirePatient,
  optionalAuth,
  asyncHandler,
};
