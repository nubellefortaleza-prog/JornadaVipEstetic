import { Request, Response, NextFunction } from 'express';

export interface ApiError extends Error {
  status?: number;
  details?: any;
}

export const errorHandler = (
  err: ApiError,
  _req: Request,
  res: Response,
  _next: NextFunction
): void => {
  const status = err.status || 500;
  const message = err.message || 'Internal server error';

  console.error(`[${status}] ${message}`, err);

  res.status(status).json({
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    ...(err.details && { details: err.details }),
  });
};

export const createApiError = (
  message: string,
  status: number = 500,
  details?: any
): ApiError => {
  const error = new Error(message) as ApiError;
  error.status = status;
  error.details = details;
  return error;
};

export const notFound = (_req: Request, _res: Response, next: NextFunction): void => {
  const error = new Error('Route not found') as ApiError;
  error.status = 404;
  next(error);
};

export default {
  errorHandler,
  createApiError,
  notFound,
};
