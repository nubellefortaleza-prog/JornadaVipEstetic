import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import config from './config';
import { initializeDatabase, closeDatabase } from './database';
import { initializeGemini } from './utils/gemini';
import { asyncHandler } from './middleware/auth';
import { errorHandler, notFound } from './middleware/errorHandler';

// Import routes
import authRoutes from './routes/auth';
import patientRoutes from './routes/patients';
import anamnesisRoutes from './routes/anamnesis';
import reminderRoutes from './routes/reminders';
import campaignRoutes from './routes/campaigns';
import evolutionRoutes from './routes/evolution';
import rewardRoutes from './routes/rewards';
import analyticsRoutes from './routes/analytics';
import webhookRoutes from './routes/webhooks';
import aiRoutes from './routes/ai';

const app = express();

// Trust proxy
app.set('trust proxy', 1);

// Security middleware
app.use(helmet());

// CORS configuration
app.use(
  cors({
    origin: config.cors.origin,
    credentials: true,
    optionsSuccessStatus: 200,
  })
);

// Body parser middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Request logging middleware (development)
if (config.nodeEnv === 'development') {
  app.use((req: Request, _res: Response, next: NextFunction) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
  });
}

// Health check endpoint
app.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
  });
});

// API Routes
app.use('/api/jornada', authRoutes);
app.use('/api/jornada', patientRoutes);
app.use('/api/jornada', anamnesisRoutes);
app.use('/api/jornada', reminderRoutes);
app.use('/api/jornada', campaignRoutes);
app.use('/api/jornada', evolutionRoutes);
app.use('/api/jornada', rewardRoutes);
app.use('/api/jornada', analyticsRoutes);
app.use('/api/jornada', webhookRoutes);
app.use('/api', aiRoutes);

// 404 handler
app.use(notFound);

// Global error handler
app.use(errorHandler);

// Initialize and start server
const startServer = async () => {
  try {
    // Initialize database
    await initializeDatabase();
    console.log('Database initialized');

    // Initialize Gemini API
    initializeGemini();
    console.log('Gemini API initialized');

    // Start listening
    app.listen(config.port, () => {
      console.log(
        `JornadaVip Backend Server running on ${config.apiUrl}:${config.port}`
      );
      console.log(`Environment: ${config.nodeEnv}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  await closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT signal received: closing HTTP server');
  await closeDatabase();
  process.exit(0);
});

startServer();

export default app;
