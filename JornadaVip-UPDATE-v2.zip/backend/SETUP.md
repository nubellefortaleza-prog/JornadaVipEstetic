# JornadaVip Backend - Complete Setup Guide

This guide walks you through setting up and running the JornadaVip backend API.

## Quick Start (5 minutes)

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

Copy and customize `.env.example`:

```bash
cp .env.example .env
```

At minimum, configure:
- `DB_PASSWORD` - Your PostgreSQL password
- `JWT_SECRET` - A random string (use: `openssl rand -hex 32`)
- `CORS_ORIGIN` - Your frontend URL

### 3. Create Database

```bash
# Create PostgreSQL database
createdb jornadavip

# Run migrations
psql -U postgres -d jornadavip -f migrations/001_initial.sql
```

### 4. Seed Initial Data

```bash
npm run seed
```

This creates:
- Admin user: `admin` / `admin123` (change in production!)
- 3 sample patients with rewards records

### 5. Start Development Server

```bash
npm run dev
```

Server runs at: `http://localhost:3000`

Test with: `curl http://localhost:3000/health`

## Detailed Setup Instructions

### Prerequisites

**System Requirements:**
- Node.js 20+ ([download](https://nodejs.org/))
- PostgreSQL 12+ ([download](https://www.postgresql.org/download/))
- npm or yarn

**Verify Installation:**

```bash
node --version    # Should be v20+
npm --version     # Should be v10+
psql --version    # Should be 12+
```

### Step 1: Database Setup

#### Create PostgreSQL Database

```bash
# On macOS (homebrew)
createdb jornadavip

# On Windows/Linux
psql -U postgres -c "CREATE DATABASE jornadavip;"
```

#### Run Migrations

```bash
# Using psql directly
psql -U postgres -d jornadavip -f migrations/001_initial.sql

# Or import the SQL file manually in your DB client
```

This creates all necessary tables with proper indexes:
- admin_users
- patients
- anamnesis
- reminders
- campaigns, campaign_reads
- evolution_entries
- rewards
- analytics_events
- webhook_configs
- refresh_tokens

### Step 2: Install Node Dependencies

```bash
npm install
```

This installs all packages defined in `package.json`:
- Express server framework
- PostgreSQL client (pg)
- JWT and bcrypt for authentication
- Google Generative AI for AI features
- Helmet for security headers
- CORS for cross-origin requests
- TypeScript for type safety

### Step 3: Environment Configuration

Create `.env` file from template:

```bash
cp .env.example .env
```

Edit `.env` with your settings:

```env
# Server Configuration
NODE_ENV=development
PORT=3000
API_URL=http://localhost:3000

# PostgreSQL Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jornadavip
DB_USER=postgres
DB_PASSWORD=your_database_password
DB_POOL_MIN=2
DB_POOL_MAX=10

# JWT Secrets (generate with: openssl rand -hex 32)
JWT_SECRET=your_32_character_random_string
JWT_EXPIRY=24h
JWT_REFRESH_SECRET=another_32_character_random_string
JWT_REFRESH_EXPIRY=7d

# CORS (Frontend URL - local development example)
CORS_ORIGIN=http://localhost:3000,http://localhost:3001

# Google Gemini API (optional, for AI features)
GEMINI_API_KEY=your_google_gemini_api_key

# OAuth (optional, for patient login)
GOOGLE_OAUTH_CLIENT_ID=your_google_client_id
GOOGLE_OAUTH_CLIENT_SECRET=your_google_client_secret

# Other
WEBHOOK_SIGNATURE_SECRET=your_webhook_secret
MAX_FILE_SIZE=5242880
UPLOAD_DIR=./uploads
```

**Generate secure secrets:**

```bash
# Generate JWT secrets
openssl rand -hex 32
```

### Step 4: Seed Database with Initial Data

```bash
npm run seed
```

This script:
1. Creates default admin user
   - Username: `admin`
   - Password: `admin123` (MUST change in production)
2. Creates 3 sample patients
3. Sets up reward records for each patient

**Important:** Change the default admin password after first login!

### Step 5: Start the Server

**Development Mode (with hot reload):**

```bash
npm run dev
```

**Production Mode:**

```bash
npm run build
npm start
```

**Expected Output:**

```
Database connected successfully at 2024-03-14T10:30:00.000Z
Gemini API initialized
JornadaVip Backend Server running on http://localhost:3000:3000
Environment: development
```

## Testing the API

### Health Check

```bash
curl http://localhost:3000/health
```

Response:
```json
{
  "status": "ok",
  "timestamp": "2024-03-14T10:30:00.000Z"
}
```

### Admin Login

```bash
curl -X POST http://localhost:3000/api/jornada/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

Response:
```json
{
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "user": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "username": "admin",
      "role": "master"
    }
  }
}
```

### Get All Patients (with token)

```bash
curl -X GET http://localhost:3000/api/jornada/patients \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## File Structure

```
backend/
├── src/
│   ├── index.ts              # Express server entry point
│   ├── config.ts             # Environment configuration
│   ├── database.ts           # PostgreSQL connection pool
│   ├── middleware/
│   │   ├── auth.ts           # JWT authentication middleware
│   │   ├── validation.ts     # Request validation
│   │   └── errorHandler.ts   # Global error handler
│   ├── routes/
│   │   ├── auth.ts           # Authentication endpoints
│   │   ├── patients.ts       # Patient CRUD endpoints
│   │   ├── anamnesis.ts      # Patient health history
│   │   ├── reminders.ts      # Reminder management
│   │   ├── campaigns.ts      # Campaign management
│   │   ├── evolution.ts      # Progress photo diary
│   │   ├── rewards.ts        # Loyalty points system
│   │   ├── analytics.ts      # Analytics tracking
│   │   ├── webhooks.ts       # Webhook configuration
│   │   └── ai.ts             # AI assistant endpoints
│   └── utils/
│       ├── jwt.ts            # JWT utilities
│       └── gemini.ts         # Google Gemini API client
├── migrations/
│   └── 001_initial.sql       # Database schema
├── scripts/
│   └── seed.ts               # Database seeding script
├── package.json              # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
├── .env.example              # Environment variables template
├── .gitignore                # Git ignore rules
├── README.md                 # Project documentation
└── SETUP.md                  # This file
```

## Common Commands

```bash
# Start development server with auto-reload
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check TypeScript types
npm run typecheck

# Seed database with initial data
npm run seed
```

## Connecting to Frontend

The frontend (React PWA) connects to this API using:

1. **Base URL:** Set `API_URL` environment variable to backend URL
2. **Authentication:** Include JWT token in `Authorization: Bearer <token>` header
3. **CORS:** Ensure frontend URL is in `CORS_ORIGIN` environment variable

**Example Frontend Configuration:**

```typescript
// In frontend's apiService.ts
const API_BASE_URL = 'http://localhost:3000/api/jornada';
const AI_API_BASE_URL = 'http://localhost:3000/api';

// Include token in requests
const headers = {
  'Authorization': `Bearer ${accessToken}`,
  'Content-Type': 'application/json',
};
```

## Troubleshooting

### "Database connection failed"

- Verify PostgreSQL is running: `psql -U postgres -c "SELECT 1"`
- Check DB credentials in `.env` match your setup
- Ensure `jornadavip` database exists: `psql -U postgres -c "\l"`

### "JWT_SECRET not configured"

- Copy `.env.example` to `.env`: `cp .env.example .env`
- Generate new secret: `openssl rand -hex 32`
- Update `JWT_SECRET` in `.env`

### "CORS blocked from frontend"

- Add frontend URL to `CORS_ORIGIN` in `.env`
- Multiple origins: `CORS_ORIGIN=http://localhost:3000,http://localhost:3001`
- Include protocol (http/https) and port

### Port 3000 already in use

- Change `PORT` in `.env` (e.g., `PORT=3001`)
- Or kill process using port 3000:
  ```bash
  # macOS/Linux
  lsof -i :3000 | grep LISTEN | awk '{print $2}' | xargs kill -9

  # Windows
  netstat -ano | findstr :3000
  taskkill /PID <PID> /F
  ```

### TypeScript errors

```bash
# Check for errors without building
npm run typecheck

# Clear cache and rebuild
rm -rf dist node_modules
npm install
npm run build
```

## Production Checklist

Before deploying to production:

- [ ] Generate new `JWT_SECRET` and `JWT_REFRESH_SECRET`
- [ ] Change default admin password
- [ ] Set `NODE_ENV=production`
- [ ] Configure production database credentials
- [ ] Set `CORS_ORIGIN` to actual frontend URL(s)
- [ ] Configure GEMINI_API_KEY for AI features
- [ ] Set up HTTPS/SSL certificate
- [ ] Enable database backups
- [ ] Configure monitoring and error logging
- [ ] Set up rate limiting appropriately
- [ ] Run `npm run build` and use `dist/` folder
- [ ] Use environment-specific `.env` files
- [ ] Test all API endpoints with production data
- [ ] Set up CI/CD pipeline

## Support and Documentation

- **API Documentation**: See `README.md` for endpoint details
- **Database Schema**: Check `migrations/001_initial.sql`
- **Type Definitions**: TypeScript interfaces in route files
- **Error Handling**: Review `middleware/errorHandler.ts`
- **Authentication Flow**: See `routes/auth.ts`

## Additional Resources

- [Express Documentation](https://expressjs.com/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [JWT Explained](https://jwt.io/)
- [Google Generative AI API](https://ai.google.dev/)

## License

MIT - See project repository for details.
