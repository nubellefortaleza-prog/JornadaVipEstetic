import bcrypt from 'bcryptjs';
import { initializeDatabase, query, closeDatabase } from '../src/database';

const seedDatabase = async () => {
  try {
    console.log('Starting database seeding...');

    await initializeDatabase();

    // Create default admin user
    const username = 'admin';
    const password = 'admin123'; // CHANGE THIS IN PRODUCTION
    const passwordHash = await bcrypt.hash(password, 10);

    try {
      const result = await query(
        `INSERT INTO admin_users (name, username, password_hash, role)
         VALUES ($1, $2, $3, $4)
         RETURNING id, username, role`,
        ['Default Admin', username, passwordHash, 'master']
      );

      console.log('Admin user created successfully:');
      console.log(`  Username: ${username}`);
      console.log(`  Password: ${password}`);
      console.log(`  ID: ${result.rows[0].id}`);
      console.log(`  Role: ${result.rows[0].role}`);
      console.log('\nIMPORTANT: Change the default password in production!');
    } catch (error: any) {
      if (error.code === '23505') {
        console.log('Admin user already exists. Skipping...');
      } else {
        throw error;
      }
    }

    // Create some sample patients
    const samplePatients = [
      {
        name: 'Maria Silva',
        phone: '85987654321',
        email: 'maria@example.com',
        city: 'Fortaleza',
        objective: 'Aumento de lábios natural',
        style: 'natural',
      },
      {
        name: 'Ana Santos',
        phone: '85987654322',
        email: 'ana@example.com',
        city: 'Fortaleza',
        objective: 'Preenchimento facial',
        style: 'marcante',
      },
      {
        name: 'Paula Costa',
        phone: '85987654323',
        email: 'paula@example.com',
        city: 'Fortaleza',
        objective: 'Botox e limpeza de pele',
        style: 'discreto',
      },
    ];

    console.log('\nCreating sample patients...');
    for (const patient of samplePatients) {
      try {
        const result = await query(
          `INSERT INTO patients (name, phone, email, city, objective, style, comm_preference)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           RETURNING id, name`,
          [patient.name, patient.phone, patient.email, patient.city, patient.objective, patient.style, 'simples']
        );

        console.log(`  Created: ${result.rows[0].name} (${result.rows[0].id})`);

        // Create rewards for this patient
        await query(
          `INSERT INTO rewards (patient_id, total, referrals_count, registered_count, level)
           VALUES ($1, 0, 0, 0, 'Iniciante')`,
          [result.rows[0].id]
        );
      } catch (error: any) {
        if (error.code !== '23505') {
          console.error(`  Error creating patient ${patient.name}:`, error.message);
        }
      }
    }

    console.log('\nDatabase seeding completed successfully!');
    await closeDatabase();
    process.exit(0);
  } catch (error) {
    console.error('Error during seeding:', error);
    await closeDatabase();
    process.exit(1);
  }
};

seedDatabase();
